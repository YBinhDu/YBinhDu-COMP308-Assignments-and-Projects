//This function handles the following task:
//captures the form input and passes it to comments.ejs page
exports.displayInfo = function (req, res) {
  //get user input using request object
  var email = req.body.email;

  //make a reference to the email object
  var session = req.session;

  //store the email in session object
  session.email = email;

  console.log("email in session: " + session.email);

  //show the comments.ejs page and pass email to it
  res.render("comments", {
    email: email,
    commentPageTitle: "Comment"
  });
}; //end of function

//This function captures the form input and passes it to the thankyou.ejs page
exports.displayComment = function (req, res) {
  var email = req.body.email;
  var comments = req.body.comments;
  var session = req.session;
  session.email = email;
  session.comments = comments;

  console.log("email in session: " + session.email);
  console.log("comment in session: " + session.comments);

  res.render("thankyou", {
    email: email,
    comments: comments,
    
  });
};
