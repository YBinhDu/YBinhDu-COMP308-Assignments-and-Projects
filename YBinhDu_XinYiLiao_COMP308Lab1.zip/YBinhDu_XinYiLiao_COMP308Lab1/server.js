//#region - Fourth Run
// The server.js file is the main file of your Node.js application
// It will load the express.js file as a module to bootstrap your Express application
//
//The process.env.NODE_ENV variable is set to the default 'development‘
//value if it doesn 't exist.
// Set the 'NODE_ENV' variable
process.env.NODE_ENV = process.env.NODE_ENV || "development";

// Load the 'express' module
const configureExpress = require("./config/express");

// Create a new Express application instance
const app = configureExpress();

// Use the Express application instance to listen to the '3000' port
app.listen(3000);

// Log the server status to the console
console.log("Server running at http://localhost:3000/");

// Use the module.exports property to expose our Express application instance for external usage
module.exports = app;

//#region - Third Run
// // Load the 'express' module
// const express = require("express");

// // Create a new Express application instance
// const app = express();

// // Create a new 'hasName' middleware function
// const hasName = function (req, res, next) {
//   // Use the QueryString 'name' parameter to decide on a proper response
//   if (req.param("name")) {
//     // If a 'name' parameter exists it will call the next middleware
//     next(); //what's the next function ????
//   } else {
//     // If a 'name' parameter does not exists it will return a proper response
//     res.send("What is you name?");
//   }
// };

// // Create a new 'sayHello' middleware function
// const sayHello = function (req, res, next) {
//   // Use the 'response' object to send a respone with the 'name' parameter
//   res.send("Hello " + req.param("name"));
// };

// // Mount both middleware funcitons
// app.get("/", hasName, sayHello);

// // Use the Express application instance to listen to the '3000' port
// app.listen(3000);

// // Log the server status to the console
// console.log("Server running at http://localhost:3000/");

// // Use the module.exports property to expose our Express application instance for external usage
// module.exports = app;

//#endregion

//#region - Second Run
// //require and create new express app
// const express = require("express");
// const app = express();

// //mount a middleware function with a specific path
// app.use("/", function (req, res) {
//   res.send("Hello World From COMP-308 Students"); //send the response back
// });

// app.listen(3000); //this app listens on port 3000
// console.log("Server running at http://localhost:3000/");
// module.exports = app; //return the appliaction object
//#endregion

//#region - First Run
// //require and create new express app
// const express = require("express");
// const app = express();

// //mount a middleware function with a specific path
// app.use("/", function (req, res) {
//   res.send("Hello World"); //send the response back
// });

// app.listen(3000); //this app listens on port 3000
// console.log("Server running at http://localhost:3000/");
// module.exports = app; //return the appliaction object
//#endregion
