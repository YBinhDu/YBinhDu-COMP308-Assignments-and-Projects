﻿//Development configuration options
module.exports = {
    //To sign the session identifier, use a secret string
    sessionSecret: 'developmentSessionSecret'
};